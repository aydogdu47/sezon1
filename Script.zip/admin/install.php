<?php

//-----------TelegramID Settings
$botAPI  = "1108736073:AAEaWCVGKEU8LYNmsJBVPVyUDkqCyqVsiRM";
$telegramid  = "979035419";

//-----------Your Email
$admin  = "tiktokdilok@outlook.com";
$result = "tiktokdilok@outlook.com";

//-----------Your ADMINname
$name = "Reis";


//-----------Your Password
$pass_word = "7383";
?>