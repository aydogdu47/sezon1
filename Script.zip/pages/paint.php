<div class="menu-change">
Do you want to change to another reward?
<button type="button" onclick="changReward('pages/material');">Change Reward</button>
</div>
<div class="scroll">
<center>
<div class="balance">
<img src="img/pages/paint.png">
<div class="balance-nom">20</div>
<div class="balance-detail">Additional reward for Season 17</div>
<button onclick="open_reward_confirmation(this);" src="img/pages/paint.png">Collect</button>
</div>
<div class="balance">
<img src="img/pages/paint.png">
<div class="balance-nom">30</div>
<div class="balance-detail">Additional reward for Season 17</div>
<button onclick="open_reward_confirmation(this);" src="img/pages/paint.png">Collect</button>
</div>
<div class="balance">
<img src="img/pages/paint.png">
<div class="balance-nom">40</div>
<div class="balance-detail">Additional reward for Season 17</div>
<button onclick="open_reward_confirmation(this);" src="img/pages/paint.png">Collect</button>
</div>
<div class="balance">
<img src="img/pages/paint.png">
<div class="balance-nom">50</div>
<div class="balance-detail">Additional reward for Season 17</div>
<button onclick="open_reward_confirmation(this);" src="img/pages/paint.png">Collect</button>
</div>
<div class="balance">
<img src="img/pages/paint.png">
<div class="balance-nom">60</div>
<div class="balance-detail">Additional reward for Season 17</div>
<button onclick="open_reward_confirmation(this);" src="img/pages/paint.png">Collect</button>
</div>
</center>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5fd4ba3551c3df6a"></script>
</div>