<div class="menu-change">
Do you want to change to another reward?
<button type="button" onclick="changReward('pages/uc');">Change Reward</button>
</div>
<div class="scroll">
<center>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/1.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/1.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/2.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/2.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/3.jpg">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/3.jpg">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/4.jpg">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/4.jpg">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/5.jpg">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/5.jpg">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/6.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/6.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/7.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/7.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/8.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/8.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/9.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/9.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/10.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/10.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/11.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/11.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/12.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/12.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/13.jpg">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/13.jpg">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/14.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/14.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/15.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/15.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/16.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/16.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/17.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/17.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/18.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/18.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/19.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/19.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/20.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/20.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/21.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/21.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/22.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/22.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/23.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="2img/pages/23.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/24.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/24.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/25.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/25.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/26.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/26.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/27.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/27.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/28.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/28.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/29.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/29.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/30.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/30.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/31.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/31.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/32.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/32.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/33.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/33.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/34.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/34.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="img/pages/35.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="img/pages/35.png">Collect</button>
</div>
</div>
</center>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5fd4ba3551c3df6a"></script>
</div>